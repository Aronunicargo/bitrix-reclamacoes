require("dotenv").config();

// const BITRIX_URL = "https://b24-uo83v5.bitrix24.com.br/rest/1/11w66rs2lcjy5bfa";
//  const BITRIX_URL = "https://unicargo.bitrix24.com.br/rest/90/t4jbolt6tm0w2gim/"; //pROD//

const BITRIX_URL = process.env.BASE_URL;

module.exports = { BITRIX_URL };
